using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MatchingGame
{
    public partial class Form1 : Form
    {
        // Генератор случайных чисел для выбора иконок
        Random random = new Random();

        // Каждая буква — иконка в шрифте Webdings. Каждая иконка встречается дважды.
        List<string> icons = new List<string>()
        {
            "!", "!", "N", "N", ",", ",", "k", "k",
            "b", "b", "v", "v", "w", "w", "z", "z"
        };

        // Ссылки на первую и вторую выбранные метки
        Label firstClicked = null;
        Label secondClicked = null;

        public Form1()
        {
            InitializeComponent();
            AssignIconsToSquares();
        }

        /// <summary>
        /// Назначает каждой метке случайную иконку из списка.
        /// </summary>
        private void AssignIconsToSquares()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    // Скрываем иконку: цвет шрифта = цвет фона
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icons.RemoveAt(randomNumber);
                }
            }
        }

        /// <summary>
        /// Обработчик клика для всех 16 меток.
        /// </summary>
        private void label_Click(object sender, EventArgs e)
        {
            // Пока таймер работает, игнорируем клики
            if (timer1.Enabled == true)
                return;

            Label clickedLabel = sender as Label;

            if (clickedLabel != null)
            {
                // Если иконка уже открыта — игнорируем клик
                if (clickedLabel.ForeColor == System.Drawing.Color.Black)
                    return;

                // Первый клик
                if (firstClicked == null)
                {
                    firstClicked = clickedLabel;
                    firstClicked.ForeColor = System.Drawing.Color.Black;
                    return;
                }

                // Второй клик
                secondClicked = clickedLabel;
                secondClicked.ForeColor = System.Drawing.Color.Black;

                // Проверяем, не выиграл ли игрок
                CheckForWinner();

                // Если иконки совпали — оставляем открытыми
                if (firstClicked.Text == secondClicked.Text)
                {
                    firstClicked = null;
                    secondClicked = null;
                    return;
                }

                // Иначе запускаем таймер, чтобы скрыть иконки
                timer1.Start();
            }
        }

        /// <summary>
        /// Таймер срабатывает один раз: прячет обе иконки и сбрасывает ссылки.
        /// </summary>
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;

            firstClicked = null;
            secondClicked = null;
        }

        /// <summary>
        /// Проверяет, все ли иконки открыты. Если да — показывает сообщение и закрывает форму.
        /// </summary>
        private void CheckForWinner()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;

                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor)
                        return;
                }
            }

            MessageBox.Show("You matched all the icons!", "Congratulations");
            Close();
        }
    }
}
